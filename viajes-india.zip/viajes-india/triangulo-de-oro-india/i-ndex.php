<!DOCTYPE>
<html lang="es">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <title>Viajes Triangulo de Oro India Itinerario, Paquetes de Viajes Triangulo de Oro India a 2023-2024</title>
      <meta name="Description" content="Solicite gratis su presupuesto de viaje a Triangulo de Oro India 100% personalizado con una agencia local. Viaje auténtico a Triangulo de Oro India paquetes. Consulte el itinerario de la viaje por Triangulo de Oro India de cinco a diez días o de 5 a 20 días."/>
      <meta name="Keywords" content="viaje Triangulo de Oro India, paquetes Triangulo de Oro India, Triangulo de Oro India tour, Triangulo de Oro India itinerario, Triangulo de Oro India Viajes"/>
      <?php include("../../head.php"); ?>
      <link rel="stylesheet" href="<?=BASE_URL?>css/slippry-2.css">
      <link rel="stylesheet" href="<?=BASE_URL?>css/owl.carousel.css"/>
   </head>
   <body class="wsmenucontainer clearfix">
      <!--header-->
      <?php include ('../../header.php') ?>
      <!--End header-->
      
<section class="banner-caption">      
      <div class="container image-area" style="background-image: url(<?=BASE_URL?>images/banner/tajmahal-tt.jpg); ">  
       
      </div>      
    </section>
    <div class="home-banner-caption">
            <div class="banner-text-holder">
               <div class="title">Delhi Agra y Jaipur</div>
               <div class="tagline">Increíble itinerario turístico que comprende las tres ciudades famosas de la India</div>
            </div>
         </div>
 
<section class="full-breds"><div class="container"><div class="bredcums"><a href="<?=BASE_URL?>">Home</a> » <a href="<?=BASE_URL?>india/">India</a> » <a href="<?=BASE_URL?>india/rajasthan-tours/">Rajasthan</a> » Ranthambore Tours</div></div></section>


      <section id="about_info_this_page" class="topover_view padding-35">
         <div class="container">
            <div class="row">
               <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                  <article>
                     <h1 class="banner-caption-heading">Triangulo de Oro India 2023-2024</h1>
                     <p class="banner-caption-tag-line">
                       
<p>¿Listo para probar diferentes sabores de la cultura y tradición india? Reserve el paquete turístico Triangulo de Oro India de Tusk Travel y planifique un viaje para explorar diferentes lados de la India. Disfrute de diferentes culturas y planifique su itinerario de acuerdo con una experiencia emocionante ahora.</p>
                 </p>

                     <div class="more-read">
                                               
<p>El Jaipur de Rajasthan más hermoso y encantador con la rica herencia de Delhi y la cautivadora cultura de Agra lo harán sentir asombrado cuando salga a explorar algo grandioso y único. Desde Amer Fort y Red Fort hasta City Palace y Agra Fort, obtendrá mucho para explorar que su corazón siempre desea.</p>
<p>Tenemos varios paquetes turísticos del triángulo dorado en India, como Triangulo de Oro con Ranthambore, Triangulo de Oro con Varanasi, presupuesto y lujo Triangulo de Oro Tours. El tour Delhi Agra Jaipur tiene un rango de 5 noches / 6 días según sus requisitos para permanecer en el programa y explorar más.</p>
<p>Explore el rico patrimonio y la cultura para tener el mejor sabor de la importancia de la diversa cultura india. Este Tour del Triángulo de Oro de la India definitivamente le ofrecerá una experiencia increíble y los paquetes asequibles lo harán asombrar.</p>
<p>¡Ahora, planifique su itinerario y haga las maletas para comenzar hoy mismo!</p>    
                        
                     </div>
                     <a href="#" class="click_me" style="margin-left:0">Lee mas +</a>
                  </article>
               </div>
            </div>
         </div>
      </section>
     
<section class="package-1-format">  
<div class="container">
   <div class="row less-pading-row">
    <div class="col-md-12">
    <h2 class="text-center">Paquetes Triangulo de Oro India</h2>
                    <p class="text-center home-intro">El tour más popular de la India, visitará los tres sitios famosos del noroeste de la India: Delhi, Agra y Jaipur, conocidos como el Triángulo Dorado.</p>
</div>


                <div class="col-md-4 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>viajes-india/triangulo-de-oro-india-en-7-dias.html"><img src="<?=BASE_URL?>img/taj-mahal-01.jpg" width="100%" alt="Triángulo de oro India"> 
                            <!-- <div class="thumbnail-ribbon">
                              <span>Más popular</span>
                            </div> -->
                            

                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>viajes-india/triangulo-de-oro-india-en-7-dias.html">7 Días – Triángulo de oro India</a></h3>

                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                             Delhi - Agra - Fatehpur Sikri - Jaipur - Delhi
                            </div>

                            <p class="package-days1"><i class="flaticon-time"></i> 7 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>viajes-india/triangulo-de-oro-india-en-7-dias.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>

<div class="col-md-4 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>viajes-india/triangulo-dorado-y-haridwar-rishikesh-viaje.html"><img src="<?=BASE_URL?>img/yoga-rishikesh-tt-00.jpg" width="100%" alt="">
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>viajes-india/triangulo-dorado-y-haridwar-rishikesh-viaje.html">9 Días – India Yoga y Meditación Tour</a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Delhi - Jaipur - Agra - Haridwar - Rishikesh - Delhi
                            </div>
                            <p class="package-days1"><i class="flaticon-time"></i> 9 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star-o"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>viajes-india/triangulo-dorado-y-haridwar-rishikesh-viaje.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>


                <div class="col-md-4 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>viajes-india/viaje-rajasthan-en-10-dias.html"><img src="<?=BASE_URL?>img/jaipur-tt-02.jpg" width="100%" alt="viaje rajasthan en 10 dias">
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>viajes-india/viaje-rajasthan-en-10-dias.html">10 Días – Viajes Taj Mahal y Rajasthan</a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                             Delhi - Agra - Jaipur - Jodhpur - Udaipur - Delhi
                            </div>
                            <p class="package-days1"><i class="flaticon-time"></i> 10 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>viajes-india/viaje-rajasthan-en-10-dias.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>
               
<div class="clearfix"> </div>

<div class="col-md-4 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>viajes-a-india/viaje-india-en-10-dias-paquetes.html"><img src="<?=BASE_URL?>img/north-india-cutlure-tt.jpg" width="100%" alt="tour packages">
                            
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>viajes-a-india/viaje-india-en-10-dias-paquetes.html">10 Días – Viaje India Clásica y Benarés</a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Delhi - Jaipur - Agra - Khajuraho - Benarés - Delhi
                            </div>

                            <p class="package-days1"><i class="flaticon-time"></i> 10 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star-o"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>viajes-a-india/viaje-india-en-10-dias-paquetes.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>



<div class="col-md-4 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>viajes-india/viaje-taj-mahal-y-tigres-safari-en-india.html"><img src="<?=BASE_URL?>img/ranthambhore-tiger-tt-01.jpg" width="100%" alt="Taj Mahal y Tigres safari en India">
                            
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>viajes-india/viaje-taj-mahal-y-tigres-safari-en-india.html">10 Días – Taj Mahal y Tigres safari en India</a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Delhi - Jaipur – Ranthambore - Agra - Delhi

                            </div>

                            <p class="package-days1"><i class="flaticon-time"></i> 10 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star-o"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>viajes-india/viaje-taj-mahal-y-tigres-safari-en-india.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>




                <div class="col-md-4 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>viajes-india/triangulo-dorado-y-varanasi-paquetes.html"><img src="<?=BASE_URL?>img/varanasi-tusktravel-09.jpg" width="100%" alt="viaje Triángulo Dorado con Benarés 9 dias">
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>viajes-india/triangulo-dorado-y-varanasi-paquetes.html">9 Días – Triangulo de Oro con Benarés</a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                             Delhi - Benarés - Agra - Jaipur - Delhi
                            </div>
                            <p class="package-days1"><i class="flaticon-time"></i> 9 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>viajes-india/triangulo-dorado-y-varanasi-paquetes.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>


    <div class="clearfix"> </div>                    

    <div class="col-md-4 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>viajes-india/triangulo-dorado-y-goa-viajes.html"><img src="<?=BASE_URL?>img/goa-tusktravel-08.jpg" width="100%" alt="viaje Triángulo Dorado con Goa 9 dias">
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>viajes-india/triangulo-dorado-y-goa-viajes.html">9 Días – Triangulo de Oro con Goa</a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                             Delhi - Agra - Jaipur - Goa

                            </div>
                            <p class="package-days1"><i class="flaticon-time"></i> 9 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>viajes-india/triangulo-dorado-y-goa-viajes.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>

 <div class="col-md-4 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>viajes-india/triangulo-de-oro-india-en-6-dias.html"><img src="<?=BASE_URL?>img/agra-tusktravel-08.jpg" width="100%" alt="viaje rajasthan en 10 dias">
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>viajes-india/triangulo-de-oro-india-en-6-dias.html">10 Días – Viajes Taj Mahal y Rajasthan</a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                             Delhi - Jaipur - Agra - Delhi
                            </div>
                            <p class="package-days1"><i class="flaticon-time"></i> 10 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>viajes-india/triangulo-de-oro-india-en-6-dias.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>

                        


                        


                <div class="col-md-4 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>viajes-india/lujo-viaje-a-rajasthan-itinerario.html"><img src="<?=BASE_URL?>img/udaipur-tt-01.jpg" width="100%" alt="viaje rajasthan Lujo en 10 dias">
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>viajes-india/lujo-viaje-a-rajasthan-itinerario.html">10 Días – Viajes Lujo India Rajasthan</a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                             Delhi - Agra - Jaipur - Udaipur - Delhi
                            </div>
                            <p class="package-days1"><i class="flaticon-time"></i> 10 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>viajes-india/lujo-viaje-a-rajasthan-itinerario.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
               </div>
       
   <div class="clearfix"> </div>
   
 <div class="col-md-4 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>viajes-india/triangulo-de-oro-y-mumbai-ajanta-ellora.html"><img src="<?=BASE_URL?>img/mumbai-tusktravel-01.jpg" width="100%" alt="viaje Triángulo Dorado con Mumbai Ajanta 10 dias">
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>viajes-india/triangulo-de-oro-y-mumbai-ajanta-ellora.html">10 Días – Viaje Triangulo de oro con Mumbai Ajanta y Ellora </a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                             Delhi - Agra - Jaipur - Udaipur - Mumbai - Aurangabad - Mumbai

                            </div>
                            <p class="package-days1"><i class="flaticon-time"></i> 10 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>viajes-india/triangulo-de-oro-y-mumbai-ajanta-ellora.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>


 <div class="col-md-4 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>viajes-india/triangulo-de-oro-y-udaipur.html"><img src="<?=BASE_URL?>img/udaipur-tt-03.jpg" width="100%" alt="viaje Triángulo Dorado con Udaipur 10 dias">
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>viajes-india/triangulo-de-oro-y-udaipur.html">10 Días – Triangulo de Oro con Udaipur</a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                             Delhi - Udaipur - Jaipur - Agra - Delhi
                            </div>
                            <p class="package-days1"><i class="flaticon-time"></i> 10 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>viajes-india/triangulo-de-oro-y-udaipur.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>



</div>
</section>
 <?php include ('../dest-sec-india.php') ?> 

      
      <?php include ('../../footer.php') ?> 
      <!--End footer-->
      <?php include ('../../model.php') ?>
      <?php include ('../../script.php') ?>
   </body>
</html>