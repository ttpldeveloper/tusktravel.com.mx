<!DOCTYPE>
<html lang="es">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <title>Viajes a Benarés, Itinerario de Benarés, Paquetes de Viajes Benarés a 2023-2024</title>
      <meta name="Description" content="Solicite gratis su presupuesto de viaje a Benarés 100% personalizado con una agencia local. Viaje auténtico a Benarés paquetes. Consulte el itinerario de la viaje por Benarés de cinco a diez días o de 5 a 20 días."/>
      <meta name="Keywords" content="viaje Benarés, paquetes Benarés, Benarés tour, Benarés itinerario, Benarés Viajes"/>
      <?php include("../../head.php"); ?>
      <link rel="stylesheet" href="<?=BASE_URL?>css/slippry-2.css">
      <link rel="stylesheet" href="<?=BASE_URL?>css/owl.carousel.css"/>
   </head>
   <body class="wsmenucontainer clearfix">
      <!--header-->
      <?php include ('../../header.php') ?>
      <!--End header-->
      <!--START BANNER HTML CODE-->
      <section class="slier_holer">
         <section id="news-demo" style="overflow:hidden">
            <article><img src="<?=BASE_URL?>images/banner/benares-tt.jpg" width="" alt="Benares Viajes" /></article>
         </section>
         <div class="home-banner-caption">
            <div class="banner-text-holder">
               <div class="title">Viajes a Benarés</div>
               <div class="tagline">Una visita al paraíso espiritual de la India</div>
            </div>
         </div>
      </section>
      <section id="about_info_this_page" class="topover_view padding-35">
         <div class="container">
            <div class="row">
               <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                  <article>
                     <h1 class="banner-caption-heading">Paquetes de Viajes a Benarés 2023-2024</h1>
                     <p class="banner-caption-tag-line">
                       
India, la capital espiritual de la India. Ubicado a orillas del río Ganges (Ganga) en el estado de Uttar Pradesh, Benarés  exhibe la verdadera esencia de la India. Durante más de 2000 años, Benarés  ha sido un centro de aprendizaje y civilización.

</p>

                     <div class="more-read">

<p>Benarés  es uno de esos lugares donde puede encontrar un equilibrio perfecto entre la civilización antigua y la moderna y necesita convertirlo en el destino principal para su próximo plan de viaje a la India.</p><p>

Benarés  es conocida en todo el mundo por ser una de las ciudades vivas más antiguas del mundo. Hoy en día, Benarés , también llamada Benaras o Kashi, no es solo un lugar turístico, sino un importante lugar de peregrinación para los hindúes. Es una tierra de templos, la ciudad del Señor Shiva, y el río sagrado Ganges la atraviesa como los nervios de un cuerpo. La ciudad atrae a miles de peregrinos, turistas y aún más entusiastas de la fotografía aquí.</p>
<p>Además, los lugares para visitar alrededor de Benarés  forman una lista enorme. El templo Shri Kashi Vishwanath, Assi Ghat, Manikarnika Ghat, Dashashwamedh Ghat, Panchganga Ghat, Hanuman Ghat, el templo Durga y la mezquita Alamgir son los pocos lugares famosos. Aparte de esto, debes visitar la Universidad Hindú de Benaras. Un viaje de un día a Sarnath, un lugar sagrado para los budistas, también debería estar en su lista de deseos.</p>
<p><br />Esta ciudad está bien comunicada por aire, tren y carretera. Puede viajar en tren desde Delhi o cualquier otra ciudad importante de India como Mumbai y Kolkata. O si prefiere los viajes por carretera, también puede hacerlo. En la ciudad, puedes elegir auto-rickshaws para viajar.</p>
<p>Benarés  ofrece muchos lugares para quedarse para los visitantes. Puede elegir entre una amplia variedad de alojamientos, desde hoteles de lujo hasta casas de huéspedes económicas. Esta ciudad recibe a miles de turistas por año, por lo tanto, puede obtener un lugar para quedarse según su elección poniéndose en contacto con nosotros. Nuestra guía de viaje exclusiva de Benaras te ayudará en todo.</p>
                     </div>
                     <a href="#" class="click_me" style="margin-left:0">Lee mas +</a>
                  </article>
               </div>
            </div>
         </div>
      </section>
     
<section class="package-1-format">  
<div class="container">
   <div class="row less-pading-row">

<div class="col-md-4 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>paquetes/15-dias-viaje-india-y-nepal.html"> <img src="<?=BASE_URL?>img/guest/varanasi-ganges-spiritual-experience.jpg" alt="Benarés  Ganges Spiritual Experience"></a> 
                            <div class="thumbnail-ribbon">
                              <span>Más popular</span>
                            </div>
                        </div>
                        <div class="destination-content-1">
                          <h3><a href="<?=BASE_URL?>paquetes/15-dias-viaje-india-y-nepal.html">15 Días – Viaje India y Nepal</a></h3>
                          <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Delhi - Udaipur - Ranakpur - Jodhpur - Jaipur - Agra - Khajuraho -Varanasi - Kathmandu - Pokhara
                            </div>
                              <p class="package-days1"><i class="flaticon-time"></i> 15 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>paquetes/15-dias-viaje-india-y-nepal.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>

<div class="col-md-4 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>paquetes/viajes-india-y-maldivas.html">
                            <img src="<?=BASE_URL?>img/maldives-scuba-diving-05.jpg" width="100%" alt="">
                           </a>
                           <div class="thumbnail-ribbon">
                              <span>Más popular</span>
                            </div>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>paquetes/viajes-india-y-maldivas.html">14 Días – Viajes India y Maldivas</a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Delhi – Agra – Jaipur – Varanasi – Delhi - Male - Salida
                            </div>
                            <p class="package-days1"><i class="flaticon-time"></i> 14 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star-o"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>paquetes/viajes-india-y-maldivas.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>



<div class="col-md-4 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>paquetes/india-y-nepal-viaje-en-20-dias.html"><img src="<?=BASE_URL?>img/nepal-tusktravel-00.jpg" width="100%" alt="tour packages">
                            <div class="thumbnail-ribbon">
                                 <span>Más popular</span>
                              </div>
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>paquetes/india-y-nepal-viaje-en-20-dias.html">20 Días – Viaje Mejor de India y Nepal </a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Delhi – Udaipur – Ranakpur - Jodhpur – Jaipur – Fatehpur Sikri - Agra - Delhi - Varanasi - Delhi - Katmandú - Nagarkot - Delhi
                            </div>

                            <p class="package-days1"><i class="flaticon-time"></i> 10 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star-o"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>paquetes/india-y-nepal-viaje-en-20-dias.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>viajes-india/triangulo-de-oro-india-en-7-dias.html"><img src="<?=BASE_URL?>img/guest/varanasi-guest-arrival.jpg" width="100%" alt="tour packages"> 
                            <div class="thumbnail-ribbon">
                              <span>Más popular</span>
                            </div>
                            

                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>viajes-india/triangulo-de-oro-india-en-7-dias.html">7 Días – Triángulo de oro India (Delhi Agra jaipur)</a></h3>

                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Nueva Delhi - Agra - Fatehpur Sikri - Jaipur - Delhi
                            </div>

                            <p class="package-days1"><i class="flaticon-time"></i> 7 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>viajes-india/triangulo-de-oro-india-en-7-dias.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>
               
                

                <div class="col-md-4 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>viajes-india/viaje-rajasthan-en-10-dias.html"><img src="<?=BASE_URL?>img/rajasthan-tusktravel-016.jpg" width="100%" alt="viaje rajasthan en 10 dias">
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>viajes-india/viaje-rajasthan-en-10-dias.html">10 Días – Viajes a Rajasthán y Taj Mahal (Cultura de la India)</a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                             Delhi - Agra - Jaipur - Jodhpur - Udaipur - Delhi
                            </div>
                            <p class="package-days1"><i class="flaticon-time"></i> 10 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>viajes-india/viaje-rajasthan-en-10-dias.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>
                              
                

                <div class="col-md-4 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>viajes-india/triangulo-dorado-y-haridwar-rishikesh-viaje.html"><img src="<?=BASE_URL?>img/rishikesh-tusktravel-01.jpg" width="100%" alt="">
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>viajes-india/triangulo-dorado-y-haridwar-rishikesh-viaje.html">9 Días – Triángulo de Oro con Yoga y Meditación</a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Delhi - Jaipur - Agra - Haridwar - Rishikesh - Delhi
                            </div>
                            <p class="package-days1"><i class="flaticon-time"></i> 9 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star-o"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>viajes-india/triangulo-dorado-y-haridwar-rishikesh-viaje.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>

   <div class="clearfix"> </div>

 <div class="col-md-3 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>paquetes/viaje-a-india-nepal-y-butan.html">
                            <img src="<?=BASE_URL?>img/nepal-tusktravel-013.jpg" width="100%" alt="">
                            <div class="thumbnail-ribbon">
                                 <span>Más popular</span>
                              </div>
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>paquetes/viaje-a-india-nepal-y-butan.html">14 Días – Viaje India, Nepal y Bután</a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Delhi – Jaipur – Agra – Katmandú -  Paro – Thimpu - Delhi - Salida
                            </div>
                            <p class="package-days1"><i class="flaticon-time"></i> 14 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star-o"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>paquetes/viaje-a-india-nepal-y-butan.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>

 


                 <div class="col-md-3 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>paquetes/viaje-india-y-tailandia-paquetes.html">
                            <img src="<?=BASE_URL?>img/tailandia-tusktravel-03.jpg" width="100%" alt="">
                            <div class="thumbnail-ribbon">
                                 <span>Más popular</span>
                              </div>
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>paquetes/viaje-india-y-tailandia-paquetes.html">14 Días – Viaje Paquetes India y Tailandia</a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Delhi - Jaipur - Agra - Khajuraho - Varanasi - Chaing Mai - Phuket - Bangkok
                            </div>
                            <p class="package-days1"><i class="flaticon-time"></i> 14 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star-o"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>paquetes/viaje-india-y-tailandia-paquetes.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>

<div class="col-md-3 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>viajes-india/viajes-rajasthan-y-varanasi.html"><img src="<?=BASE_URL?>img/guest/jaipur-elephant-ride-guest.jpg" width="100%" alt="">
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>viajes-india/viajes-rajasthan-y-varanasi.html">14 Días – India Rajasthan y Benarés </a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Delhi - Udaipur – Ranakpur – Jodhpur - Jaipur - Agra - Delhi - Varanasi - Delhi
                            </div>
                            <p class="package-days1"><i class="flaticon-time"></i> 14 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star-o"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>viajes-india/viajes-rajasthan-y-varanasi.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>
       

<div class="col-md-3 col-sm-4 col-xs-12 less-pading-col">

                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>paquetes/viaje-paquetes-india-y-dubai.html"> <img src="<?=BASE_URL?>img/dubai-tusktravel-00.jpg" alt="Varanasi Ganges Spiritual Experience"></a> 
                            <div class="thumbnail-ribbon">
                              <span>Más popular</span>
                            </div>
                        </div>
                        <div class="destination-content-1">
                          <h3><a href="<?=BASE_URL?>paquetes/viaje-paquetes-india-y-dubai.html">14 Días – Viaje India y Dubái </a></h3>
                          <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Delhi - Jaipur - Agra - Khajuraho - Varanasi - Delhi - Dubai - Salida
                            </div>
                              <p class="package-days1"><i class="flaticon-time"></i> 15 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>paquetes/viaje-paquetes-india-y-dubai.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>

              
                
 
</div>
</section>

      
      <?php include ('../../footer.php') ?> 
      <!--End footer-->
      <?php include ('../../model.php') ?>
      <?php include ('../../script.php') ?>
   </body>
</html>