<!DOCTYPE>
<html lang="es">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <title>Viajes a Sur de India Itinerario, Paquetes de Viajes Sur de India a 2023-2024</title>
      <meta name="Description" content="Solicite gratis su presupuesto de viaje a Sur de India 100% personalizado con una agencia local. Viaje auténtico a Sur de India paquetes. Consulte el itinerario de la viaje por Sur de India de cinco a diez días o de 5 a 20 días."/>
      <meta name="Keywords" content="viaje Sur de India, paquetes Sur de India, Sur de India tour, Sur de India itinerario, Sur de India Viajes"/>
      <?php include("../../head.php"); ?>
      <link rel="stylesheet" href="<?=BASE_URL?>css/slippry-2.css">
      <link rel="stylesheet" href="<?=BASE_URL?>css/owl.carousel.css"/>
   </head>
   <body class="wsmenucontainer clearfix">
      <!--header-->
      <?php include ('../../header.php') ?>
      <!--End header-->
      
<section class="banner-caption">      
      <div class="container image-area" style="background-image: url(<?=BASE_URL?>images/banner/sur-de-india-tt.jpg); ">         
    <div class="home-banner-caption">
            <div class="banner-text-holder">
               <h1 class="title">Viajes Sur de la India</h1>
               <div class="tagline">Templo, estaciones de montaña, remansos y hermosas playas.</div>
            </div>
         </div>
   </div>      
    </section>
<!---START breadcrumbs-->
  <section class="full-breds"><div class="container"><div class="bredcums"><?= breadcrumbs() ?></div></div></section>
<!---END breadcrumbs-->


      <section id="about_info_this_page" class="topover_view padding-35 tuskbg">
         <div class="container">
            <div class="row">
               <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                  <article>              
<p>El sur de la India tiene mucho más que ofrecer que simples playas y plantaciones de especias. Es un crisol de culturas, cocinas, tradiciones e idiomas. Desde parejas en luna de miel hasta familias, los estados sureños de Kerala, Karnataka, Andhra Pradesh y Tamil Nadu reciben a los turistas con calidez y amor.
                     </p>
                     <p>Sur de la India por primera vez, será una experiencia mezclada con diferentes emociones. El sur de la India es más rico en tradiciones y cultura en comparación con el norte de la India y los visitantes por primera vez pueden encontrarlos extraños.</p>

                     <div class="more-read">
                        <p> </p>

<p>Los cinco estados principales del sur de la India son Tamil Nadu, Karnataka, Andhra Pradesh, Telangana y Kerala. Cada uno de los estados tiene diferentes idiomas, estilo de vestir, sabor de la comida, etc. Si está planeando un viaje corto, puede elegir un estado y recorrerlo completamente. Si es un viaje largo, puedes ver 2 estados. Cada estado es único a su manera. Tamil Nadu tiene muchos templos, Kerala es rica en vegetación, Andhra Pradesh tiene fuertes populares, mientras que Karnataka tiene un clima fresco con muchos parques y palacios.</p>
<p>Ya sea que busque relajarse y relajarse en la playa y en un remanso de vacaciones en Kerala, un torbellino espiritual a través de los templos y lugares de peregrinación de Tamil Nadu, un paseo por los antiguos sitios arqueológicos de Karnataka o tiempo para ir en busca de los lugares más emblemáticos de la India. vida silvestre en cualquiera de estos estados, podemos hacer que este sea verdaderamente el viaje de su vida. Definitivamente se recomienda combinar el tiempo en los tres estados, si tiene tiempo. ¡Esperamos darle la bienvenida a nuestro propio patio trasero en el sur de la India!</p>
<p><br />Destinos del sur de la India que siguen siendo los primeros en la lista de un viajero global. Los ricos templos curvos de roca en Mahabalipuram, los hermosos jardines de Bangalore, el magnífico palacio y las colinas de Chamundi en Mysore, el grupo de monumentos en Hampi y, lo que es más importante, los remansos de renombre mundial de Alleppey en Kerala son algunos de los destinos más buscados en el sur. India que ningún viajero debe perderse.</p>
                     </div>
                     <a href="#" class="click_me" style="margin-left:0">Lee mas +</a>
                  </article>
               </div>
            </div>
         </div>
      </section>
     
<section class="package-1-format tuskbg">  
<div class="container">
   <div class="row less-pading-row">
    <div class="col-md-12">
    <h2 class="text-center">Paquetes - Itinerario Sur de la India</h2>
                    <p class="text-center home-intro">Los mejores tours, viajes y paquetes vacacionales en Kerala se adaptan a la familia, pareja o amigos. Todo el itinerario se puede personalizar según su elección.</p>
</div>




 <div class="col-md-4 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>viajes-india/tour-del-templo-del-sur-de-la-india.html"><img src="<?=BASE_URL?>img/southindia-tusktravel-01.jpg" width="100%" alt="Templo del sur de la India">
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>viajes-india/tour-del-templo-del-sur-de-la-india.html">12 Días - Templo del sur de la India</a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                             Chennai - Tirupati -Mahabalipuram - Pondicherry -Tanjore - Madurai - Rameshwaram - Kanyakumari - Kovalam - Trivandrum
                            </div>
                            <p class="package-days1"><i class="flaticon-time"></i> 12 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>viajes-india/tour-del-templo-del-sur-de-la-india.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>  



 <div class="col-md-4 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>viajes-india/viaje-kerala-en-6-dias-itinerario.html"><img src="<?=BASE_URL?>img/kerala-tusktravel-07.jpg" width="100%" alt="Maravilloso Por Kerala">
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>viajes-india/viaje-kerala-en-6-dias-itinerario.html">06 Días - Maravilloso Recorrido Por Kerala</a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                             Cochin - Munnar - Kumarakom - Trivandrum - Cochin
                            </div>
                            <p class="package-days1"><i class="flaticon-time"></i> 06 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>viajes-india/viaje-kerala-en-6-dias-itinerario.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>  

  <div class="col-md-4 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>viajes-india/ayurveda-en-kerala-viaje-itinerario.html"><img src="<?=BASE_URL?>img/ayurveda-tusktravel-01.jpg" width="100%" alt="">
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>viajes-india/ayurveda-en-kerala-viaje-itinerario.html">13 Días – Viaje a Kerala (Yoga y Ayurveda)</a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Kochi - Munnar - Thekkady - Kumarakom - Alleppey Backwater - Kovalam - Varkala - Kochi
                            </div>
                            <p class="package-days1"><i class="flaticon-time"></i> 13 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star-o"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>viajes-india/ayurveda-en-kerala-viaje-itinerario.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>viajes-india/india-norte-y-sur-kerala-goa-mumbai-itinerario.html"><img src="<?=BASE_URL?>img/kerala-tusk-00.jpg" width="100%" alt="Norte de la India y auténtica Kerala">
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>viajes-india/india-norte-y-sur-kerala-goa-mumbai-itinerario.html">21 Días - Norte de la India con auténtica Kerala</a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                             Delhi – Jaipur – Agra - Khajuraho -Varanasi – Mumbai – Goa – Chennai – Munnar - Delhi
                            </div>
                            <p class="package-days1"><i class="flaticon-time"></i> 21 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>viajes-india/india-norte-y-sur-kerala-goa-mumbai-itinerario.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>  


<div class="col-md-4 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>viajes-india/15-dias-viaje-sur-india-karnataka-goa.html"><img src="<?=BASE_URL?>img/hampi-tusktravel-01.jpg" width="100%" alt="viaje rajasthan en 10 dias">
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>viajes-india/15-dias-viaje-sur-india-karnataka-goa.html">15 Días - Sur de la India Karnataka + Goa</a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                             Mumbai – Bangalore - Mysore - Hassan - Hospet – Hampi - Badami – Hubli - Goa - Mumbai
                            </div>
                            <p class="package-days1"><i class="flaticon-time"></i> 10 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>viajes-india/15-dias-viaje-sur-india-karnataka-goa.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>  


<div class="col-md-4 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>viajes-a-india/viaje-india-en-10-dias-paquetes.html"><img src="<?=BASE_URL?>img/north-india-cutlure-tt.jpg" width="100%" alt="tour packages">
                            
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>viajes-a-india/viaje-india-en-10-dias-paquetes.html">10 Días – Viaje India Clásica y Benarés</a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Delhi - Jaipur - Agra - Khajuraho - Benarés - Delhi
                            </div>

                            <p class="package-days1"><i class="flaticon-time"></i> 10 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star-o"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>viajes-a-india/viaje-india-en-10-dias-paquetes.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>
   <div class="clearfix"> </div>

                
  

 


</div>
</section>
 <?php include ('../dest-sec-india.php') ?> 

      
      <?php include ('../../footer.php') ?> 
      <!--End footer-->
      <?php include ('../../model.php') ?>
      <?php include ('../../script.php') ?>
   </body>
</html>