<!DOCTYPE>
<html lang="es">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <title>Viajes a Sur de India Itinerario, Paquetes de Viajes Sur de India a 2023-2024</title>
      <meta name="Description" content="Solicite gratis su presupuesto de viaje a Sur de India 100% personalizado con una agencia local. Viaje auténtico a Sur de India paquetes. Consulte el itinerario de la viaje por Sur de India de cinco a diez días o de 5 a 20 días."/>
      <meta name="Keywords" content="viaje Sur de India, paquetes Sur de India, Sur de India tour, Sur de India itinerario, Sur de India Viajes"/>
      <?php include("../../head.php"); ?>
      <link rel="stylesheet" href="<?=BASE_URL?>css/slippry-2.css">
      <link rel="stylesheet" href="<?=BASE_URL?>css/owl.carousel.css"/>
   </head>
   <body class="wsmenucontainer clearfix">
      <!--header-->
      <?php include ('../../header.php') ?>
      <!--End header-->
      <!--START BANNER HTML CODE-->
      <section class="slier_holer">
         <section id="news-demo" style="overflow:hidden">
            <article><img src="<?=BASE_URL?>images/banner/viaje-Sur de India.webp" width="" alt="camboya Viajes" /></article>
         </section>
         <div class="home-banner-caption">
            <div class="banner-text-holder">
               <div class="title">Viajes a Sur de India</div>
               <div class="tagline">Viajes Sur de India es una agencia de viajes especializada en viajes a India</div>
            </div>
         </div>
      </section>
      <section id="about_info_this_page" class="topover_view padding-35">
         <div class="container">
            <div class="row">
               <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                  <article>
                     <h1 class="banner-caption-heading">Paquetes de Viajes a Sur de India 2023-2024</h1>
                     <p class="banner-caption-tag-line">
                       
El sur de la India tiene mucho más que ofrecer que simples playas y plantaciones de especias. Es un crisol de culturas, cocinas, tradiciones e idiomas. Desde parejas en luna de miel hasta familias, los estados sureños de Kerala, Karnataka, Andhra Pradesh y Tamil Nadu reciben a los turistas con calidez y amor.
                     </p>

                     <div class="more-read">
                        <p> </p>
<p>Sur de la India por primera vez, será una experiencia mezclada con diferentes emociones. El sur de la India es más rico en tradiciones y cultura en comparación con el norte de la India y los visitantes por primera vez pueden encontrarlos extraños.</p>
<p>Los cinco estados principales del sur de la India son Tamil Nadu, Karnataka, Andhra Pradesh, Telangana y Kerala. Cada uno de los estados tiene diferentes idiomas, estilo de vestir, sabor de la comida, etc. Si está planeando un viaje corto, puede elegir un estado y recorrerlo completamente. Si es un viaje largo, puedes ver 2 estados. Cada estado es único a su manera. Tamil Nadu tiene muchos templos, Kerala es rica en vegetación, Andhra Pradesh tiene fuertes populares, mientras que Karnataka tiene un clima fresco con muchos parques y palacios.</p>
<p>Ya sea que busque relajarse y relajarse en la playa y en un remanso de vacaciones en Kerala, un torbellino espiritual a través de los templos y lugares de peregrinación de Tamil Nadu, un paseo por los antiguos sitios arqueológicos de Karnataka o tiempo para ir en busca de los lugares más emblemáticos de la India. vida silvestre en cualquiera de estos estados, podemos hacer que este sea verdaderamente el viaje de su vida. Definitivamente se recomienda combinar el tiempo en los tres estados, si tiene tiempo. ¡Esperamos darle la bienvenida a nuestro propio patio trasero en el sur de la India!</p>
<p><br />Destinos del sur de la India que siguen siendo los primeros en la lista de un viajero global. Los ricos templos curvos de roca en Mahabalipuram, los hermosos jardines de Bangalore, el magnífico palacio y las colinas de Chamundi en Mysore, el grupo de monumentos en Hampi y, lo que es más importante, los remansos de renombre mundial de Alleppey en Kerala son algunos de los destinos más buscados en el sur. India que ningún viajero debe perderse.</p>
                     </div>
                     <a href="#" class="click_me" style="margin-left:0">Lee mas +</a>
                  </article>
               </div>
            </div>
         </div>
      </section>
     
<section class="package-1-format">  
<div class="container">
   <div class="row less-pading-row">

<div class="col-md-4 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>paquetes/15-dias-viaje-india-y-nepal.html"> <img src="<?=BASE_URL?>img/guest/varanasi-ganges-spiritual-experience.jpg" alt="Varanasi Ganges Spiritual Experience"></a> 
                            <div class="thumbnail-ribbon">
                              <span>Más popular</span>
                            </div>
                        </div>
                        <div class="destination-content-1">
                          <h3><a href="<?=BASE_URL?>paquetes/15-dias-viaje-india-y-nepal.html">15 Días – Viaje India y Nepal</a></h3>
                          <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Delhi - Udaipur - Ranakpur - Jodhpur - Jaipur - Agra - Khajuraho -Varanasi - Kathmandu - Pokhara
                            </div>
                              <p class="package-days1"><i class="flaticon-time"></i> 15 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>paquetes/15-dias-viaje-india-y-nepal.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>

<div class="col-md-4 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>paquetes/viajes-india-y-maldivas.html">
                            <img src="<?=BASE_URL?>img/maldives-scuba-diving-05.jpg" width="100%" alt="">
                           </a>
                           <div class="thumbnail-ribbon">
                              <span>Más popular</span>
                            </div>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>paquetes/viajes-india-y-maldivas.html">14 Días – Viajes India y Maldivas</a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Delhi – Agra – Jaipur – Varanasi – Delhi - Male - Salida
                            </div>
                            <p class="package-days1"><i class="flaticon-time"></i> 14 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star-o"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>paquetes/viajes-india-y-maldivas.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>



<div class="col-md-4 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>paquetes/india-y-nepal-viaje-en-20-dias.html"><img src="<?=BASE_URL?>img/nepal-tusktravel-00.jpg" width="100%" alt="tour packages">
                            <div class="thumbnail-ribbon">
                                 <span>Más popular</span>
                              </div>
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>paquetes/india-y-nepal-viaje-en-20-dias.html">20 Días – Viaje Mejor de India y Nepal </a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Delhi – Udaipur – Ranakpur - Jodhpur – Jaipur – Fatehpur Sikri - Agra - Delhi - Varanasi - Delhi - Katmandú - Nagarkot - Delhi
                            </div>

                            <p class="package-days1"><i class="flaticon-time"></i> 10 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star-o"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>paquetes/india-y-nepal-viaje-en-20-dias.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>viajes-india/triangulo-de-oro-india-en-7-dias.html"><img src="<?=BASE_URL?>img/guest/varanasi-guest-arrival.jpg" width="100%" alt="tour packages"> 
                            <div class="thumbnail-ribbon">
                              <span>Más popular</span>
                            </div>
                            

                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>viajes-india/triangulo-de-oro-india-en-7-dias.html">7 Días – Triángulo de oro India (Delhi Agra jaipur)</a></h3>

                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Nueva Delhi - Agra - Fatehpur Sikri - Jaipur - Delhi
                            </div>

                            <p class="package-days1"><i class="flaticon-time"></i> 7 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>viajes-india/triangulo-de-oro-india-en-7-dias.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>
               
                

                <div class="col-md-4 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>viajes-india/viaje-rajasthan-en-10-dias.html"><img src="<?=BASE_URL?>img/rajasthan-tusktravel-016.jpg" width="100%" alt="viaje rajasthan en 10 dias">
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>viajes-india/viaje-rajasthan-en-10-dias.html">10 Días – Viajes a Rajasthán y Taj Mahal (Cultura de la India)</a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                             Delhi - Agra - Jaipur - Jodhpur - Udaipur - Delhi
                            </div>
                            <p class="package-days1"><i class="flaticon-time"></i> 10 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>viajes-india/viaje-rajasthan-en-10-dias.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>
                              
                

                <div class="col-md-4 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>viajes-india/triangulo-dorado-y-haridwar-rishikesh-viaje.html"><img src="<?=BASE_URL?>img/rishikesh-tusktravel-01.jpg" width="100%" alt="">
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>viajes-india/triangulo-dorado-y-haridwar-rishikesh-viaje.html">9 Días – Triángulo de Oro con Yoga y Meditación</a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Delhi - Jaipur - Agra - Haridwar - Rishikesh - Delhi
                            </div>
                            <p class="package-days1"><i class="flaticon-time"></i> 9 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star-o"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>viajes-india/triangulo-dorado-y-haridwar-rishikesh-viaje.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>

   <div class="clearfix"> </div>

 <div class="col-md-3 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>paquetes/viaje-a-india-nepal-y-butan.html">
                            <img src="<?=BASE_URL?>img/nepal-tusktravel-013.jpg" width="100%" alt="">
                            <div class="thumbnail-ribbon">
                                 <span>Más popular</span>
                              </div>
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>paquetes/viaje-a-india-nepal-y-butan.html">14 Días – Viaje India, Nepal y Bután</a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Delhi – Jaipur – Agra – Katmandú -  Paro – Thimpu - Delhi - Salida
                            </div>
                            <p class="package-days1"><i class="flaticon-time"></i> 14 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star-o"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>paquetes/viaje-a-india-nepal-y-butan.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>

 


                 <div class="col-md-3 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>paquetes/viaje-india-y-tailandia-paquetes.html">
                            <img src="<?=BASE_URL?>img/tailandia-tusktravel-03.jpg" width="100%" alt="">
                            <div class="thumbnail-ribbon">
                                 <span>Más popular</span>
                              </div>
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>paquetes/viaje-india-y-tailandia-paquetes.html">14 Días – Viaje Paquetes India y Tailandia</a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Delhi - Jaipur - Agra - Khajuraho - Varanasi - Chaing Mai - Phuket - Bangkok
                            </div>
                            <p class="package-days1"><i class="flaticon-time"></i> 14 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star-o"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>paquetes/viaje-india-y-tailandia-paquetes.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>

<div class="col-md-3 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>viajes-india/viajes-rajasthan-y-varanasi.html"><img src="<?=BASE_URL?>img/guest/jaipur-elephant-ride-guest.jpg" width="100%" alt="">
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>viajes-india/viajes-rajasthan-y-varanasi.html">14 Días – India Rajasthan y Benarés </a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Delhi - Udaipur – Ranakpur – Jodhpur - Jaipur - Agra - Delhi - Varanasi - Delhi
                            </div>
                            <p class="package-days1"><i class="flaticon-time"></i> 14 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star-o"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>viajes-india/viajes-rajasthan-y-varanasi.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>
       

<div class="col-md-3 col-sm-4 col-xs-12 less-pading-col">

                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>paquetes/viaje-paquetes-india-y-dubai.html"> <img src="<?=BASE_URL?>img/dubai-tusktravel-00.jpg" alt="Varanasi Ganges Spiritual Experience"></a> 
                            <div class="thumbnail-ribbon">
                              <span>Más popular</span>
                            </div>
                        </div>
                        <div class="destination-content-1">
                          <h3><a href="<?=BASE_URL?>paquetes/viaje-paquetes-india-y-dubai.html">14 Días – Viaje India y Dubái </a></h3>
                          <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Delhi - Jaipur - Agra - Khajuraho - Varanasi - Delhi - Dubai - Salida
                            </div>
                              <p class="package-days1"><i class="flaticon-time"></i> 15 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>paquetes/viaje-paquetes-india-y-dubai.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>

              
                
 
</div>
</section>

      
      <?php include ('../../footer.php') ?> 
      <!--End footer-->
      <?php include ('../../model.php') ?>
      <?php include ('../../script.php') ?>
   </body>
</html>