
  <div id="carousel-example-generic1" class="carousel slide" data-ride="carousel">
          <div class="carousel-inner">
            <div class="item active">
                <img src="<?=BASE_URL?>images/guest/delhi-jaipur-amer-fort-palace.jpg" />    
            </div>

         <div class="item">
                <img src="<?=BASE_URL?>images/guest/jaipur-city-palace-elephant.jpg" />
            </div>

           <div class="item">
                <img src="<?=BASE_URL?>images/guest/agra-city-sightseeing.jpg" />
            </div>


           
           <div class="item">
                <img src="<?=BASE_URL?>images/guest/jodhpur-city-tour-tusktravel.jpg" />
            </div>

            <div class="item">
                <img src="<?=BASE_URL?>images/guest/delhi-international-arrival.jpg" />
            </div>
            <div class="item">
                <img src="<?=BASE_URL?>images/rajasthan/rajasthan-tusktravel-016.jpg" />
            </div>

            
             
    
          <a class="left carousel-control" href="#carousel-example-generic1" role="button" data-slide="prev"><span class="glyphicon glyphicon-chevron-left"></span></a>
          <a class="right carousel-control" href="#carousel-example-generic1" role="button" data-slide="next"><span class="glyphicon glyphicon-chevron-right"></span></a>
       </div>
</div>

