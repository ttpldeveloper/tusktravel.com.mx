 
<div class="video_reviews_main bg-white">
                <div class="container">
                    <div class="row ">
                        <div class="col-lg-12 text-center">
                            <div class="text-center">
                                <h2>Nuestras fotos de viajeros</h2>
                                <img src="http://localhost/travel/images/header-bottom-svg.png" class="img-fluid" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 ovflgalry">
                            <div id="grid-container" class="gal mt-3">
                                <div class="gallery_col">
                                    <a href="<?=BASE_URL?>viajes-india/grupo/group-images/1.jpg" class="thumbnail" title="Tusk Travel Photo Gallery">
                                    <img src="<?=BASE_URL?>viajes-india/grupo/group-images/1.jpg" alt="Tusk Travel Guest" class="img-fluid">
                                    </a>
                                </div>
                               
                                <div class="gallery_col">
                                    <a href="<?=BASE_URL?>viajes-india/grupo/group-images/2.jpg" class="thumbnail" title="Tusk Travel Photo Gallery">
                                    <img src="<?=BASE_URL?>viajes-india/grupo/group-images/2.jpg" alt="Tusk Travel Guest" class="img-fluid">
                                    </a>
                                </div>


                                <div class="gallery_col">
                                    <a href="<?=BASE_URL?>viajes-india/grupo/group-images/3.jpg" class="thumbnail" title="Tusk Travel Photo Gallery">
                                    <img src="<?=BASE_URL?>viajes-india/grupo/group-images/3.jpg" alt="Tusk Travel Guest" class="img-fluid">
                                    </a>
                                </div>

                                <div class="gallery_col">
                                    <a href="<?=BASE_URL?>viajes-india/grupo/group-images/4.jpg" class="thumbnail" title="Tusk Travel Photo Gallery">
                                    <img src="<?=BASE_URL?>viajes-india/grupo/group-images/4.jpg" alt="Tusk Travel Guest" class="img-fluid">
                                    </a>
                                </div>
                                
                                <div class="gallery_col">
                                    <a href="<?=BASE_URL?>viajes-india/grupo/group-images/5.jpg" class="thumbnail" title="Tusk Travel Photo Gallery">
                                    <img src="<?=BASE_URL?>viajes-india/grupo/group-images/5.jpg" alt="Tusk Travel Guest" class="img-fluid">
                                    </a>
                                </div>

                                <div class="gallery_col">
                                    <a href="<?=BASE_URL?>viajes-india/grupo/group-images/6.jpg" class="thumbnail" title="Tusk Travel Photo Gallery">
                                    <img src="<?=BASE_URL?>viajes-india/grupo/group-images/6.jpg" alt="Tusk Travel Guest" class="img-fluid">
                                    </a>
                                </div>  
                                

                                <div class="gallery_col">
                                    <a href="<?=BASE_URL?>viajes-india/grupo/group-images/7.jpg" class="thumbnail" title="Tusk Travel Photo Gallery">
                                    <img src="<?=BASE_URL?>viajes-india/grupo/group-images/7.jpg" alt="Tusk Travel Guest" class="img-fluid">
                                    </a>
                                </div>

                                <div class="gallery_col">
                                    <a href="<?=BASE_URL?>viajes-india/grupo/group-images/8.jpg" class="thumbnail" title="Tusk Travel Photo Gallery">
                                    <img src="<?=BASE_URL?>viajes-india/grupo/group-images/8.jpg" alt="Tusk Travel Guest" class="img-fluid">
                                    </a>
                                </div>
                                
                                <div class="gallery_col">
                                    <a href="<?=BASE_URL?>viajes-india/grupo/group-images/9.jpg" class="thumbnail" title="Tusk Travel Photo Gallery">
                                    <img src="<?=BASE_URL?>viajes-india/grupo/group-images/9.jpg" alt="Tusk Travel Guest" class="img-fluid">
                                    </a>
                                </div>

                                <div class="gallery_col">
                                    <a href="<?=BASE_URL?>viajes-india/grupo/group-images/10.jpg" class="thumbnail" title="Tusk Travel Photo Gallery">
                                    <img src="<?=BASE_URL?>viajes-india/grupo/group-images/10.jpg" alt="Tusk Travel Guest" class="img-fluid">
                                    </a>
                                </div>                                  





                            </div>
                        </div>
                         <div class="col-12">
                            <div class="mt-4 text-center">
                                <a href="<?=BASE_URL?>quienes-somos/foto-de-viajero-invitado.html" class="theme_btn">Ver más <i class="bi bi-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div> 
