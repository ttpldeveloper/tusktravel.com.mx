

                    


<!-- Package Area Start -->
      <section class="package-area tuskbg">
         <div class="container">
           <h2 class="text-center">Viaje Combinado India</h2>
            <p></p>
            <div class="row">
               <div class="col-lg-12">
                  <div class="tusk-package owl-carousel owl-carousel-recomended">
                    
                    
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>paquetes/india-y-nepal-viaje-en-20-dias.html"><img src="<?=BASE_URL?>img/nepal-tusktravel-00.jpg" width="100%" alt="tour packages">
                            
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>paquetes/india-y-nepal-viaje-en-20-dias.html">20 Días – Viaje Mejor de India y Nepal </a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Delhi – Udaipur – Ranakpur - Jodhpur – Jaipur - Agra - Delhi - Benarés - Katmandú - Nagarkot
                            </div>

                            <p class="package-days1"><i class="flaticon-time"></i> 20 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star-o"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>paquetes/india-y-nepal-viaje-en-20-dias.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                    
                     
                     <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>paquetes/viaje-india-y-tailandia-paquetes.html">
                            <img src="<?=BASE_URL?>img/tailandia-tusktravel-03.jpg" width="100%" alt="">
                            <div class="thumbnail-ribbon">
                                 <span>Más popular</span>
                              </div>
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>paquetes/viaje-india-y-tailandia-paquetes.html">14 Días – Viaje India y Tailandia</a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Delhi - Jaipur - Agra - Khajuraho - Varanasi - Chaing Mai - Phuket - Bangkok
                            </div>
                            <p class="package-days1"><i class="flaticon-time"></i> 14 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star-o"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>paquetes/viaje-india-y-tailandia-paquetes.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
              


<div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>paquetes/viajes-a-india-y-sri-lanka.html"> <img src="<?=BASE_URL?>img/sri-lanka-sigiriya-fort-05.jpg" alt="Varanasi Ganges Spiritual Experience"></a> 
                            
                        </div>
                        <div class="destination-content-1">
                          <h3><a href="<?=BASE_URL?>paquetes/viajes-a-india-y-sri-lanka.html">15 Días – Viaje India y Sri Lanka</a></h3>
                          <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Delhi – Jaipur – Agra – Varanasi – Dambulla – Habarana – Sigiriya – Kandy – Nuwara Eliya
                            </div>
                              <p class="package-days1"><i class="flaticon-time"></i> 15 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>paquetes/viajes-a-india-y-sri-lanka.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>

                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>paquetes/viajes-india-y-maldivas.html">
                            <img src="<?=BASE_URL?>img/maldives-tt-7.jpg" width="100%" alt="">
                           </a>
                           <div class="thumbnail-ribbon">
                              <span>Más popular</span>
                            </div>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>paquetes/viajes-india-y-maldivas.html">14 Días – Viajes India y Maldivas</a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Delhi – Agra – Jaipur – Varanasi – Delhi - Male - Salida
                            </div>
                            <p class="package-days1"><i class="flaticon-time"></i> 14 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star-o"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>paquetes/viajes-india-y-maldivas.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>


                     <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>paquetes/viaje-paquetes-india-y-dubai.html"> <img src="<?=BASE_URL?>img/dubai-tusktravel-00.jpg" alt="Varanasi Ganges Spiritual Experience"></a> 
                            <div class="thumbnail-ribbon">
                              <span>Más popular</span>
                            </div>
                        </div>
                        <div class="destination-content-1">
                          <h3><a href="<?=BASE_URL?>paquetes/viaje-paquetes-india-y-dubai.html">14 Días – Viaje India y Dubái </a></h3>
                          <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Delhi - Jaipur - Agra - Khajuraho - Varanasi - Delhi - Dubai - Salida
                            </div>
                              <p class="package-days1"><i class="flaticon-time"></i> 15 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>paquetes/viaje-paquetes-india-y-dubai.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                

<!--pkg-row-start-->

<div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>paquetes/viaje-india-nepal-tibet-y-bhutan.html">
                            <img src="<?=BASE_URL?>img/bhutan-tusktravel-01.jpg" width="100%" alt="">
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>paquetes/viaje-india-nepal-tibet-y-bhutan.html">22 Días – India, Nepal, Tibet y Bután</a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Delhi – Jaipur – Agra – Katmandú – Pokhara – Lhasa – Paro – Thimphu - Taktsang - Paro
                            </div>
                            <p class="package-days1"><i class="flaticon-time"></i> 22 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star-o"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>paquetes/viaje-india-nepal-tibet-y-bhutan.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>


    
                    



                  </div>
             
               </div>
            </div>
         </div>
      </section>
      