        <?php include ('../side_form.php') ?>
        <!-- <div class="sidebar_section">
            <div class="sidebar_section_col">
              <h2>Packages by Destination</h2>
              <ul><li><a href="<?=BASE_URL?>india/rajasthan-tours/"><i class="fa fa-angle-right"></i>Rajasthan</a></li>
        <li><a href="<?=BASE_URL?>india/kerala-tours/"><i class="fa fa-angle-right"></i>Kerala</a></li>
        <li><a href="<?=BASE_URL?>india/golden-triangle-tours/"><i class="fa fa-angle-right"></i>Golden Triangle</a></li>
        <li><a href="<?=BASE_URL?>india/agra-tours/"><i class="fa fa-angle-right"></i>Agra</a></li>
                <li><a href="<?=BASE_URL?>india/delhi-tours/"><i class="fa fa-angle-right"></i>Delhi </a></li>
        <li><a href="<?=BASE_URL?>india/mumbai-tours/"><i class="fa fa-angle-right"></i>Mumbai </a></li>
        <li><a href="<?=BASE_URL?>india/goa-tours/"><i class="fa fa-angle-right"></i>Goa </a></li>
        <li><a href="<?=BASE_URL?>india/varanasi-tours/"><i class="fa fa-angle-right"></i>Varanasi</a></li>


                <div class="hide-guide-sidebar">                
                <li><a href="<?=BASE_URL?>india/north-india-tours/"><i class="fa fa-angle-right"></i>North India Tours</a></li>
                <li><a href="<?=BASE_URL?>india/south-india-tours/"><i class="fa fa-angle-right"></i>South India Tours</a></li>
                <li><a href="<?=BASE_URL?>india/central-india-tour/tours/"><i class="fa fa-angle-right"></i>Central India Tours</a></li>               
             </div>
            
              <li class="morepkg"><a href="" class="click-more-sidebar">View More [+] </a></li>
              </ul>
            </div>
          </div> -->
         
