      
        <div class="sidebar_section">
            <div class="sidebar_section_col">
              <h2>Everything About Delhi</h2>
              <ul>
                <li><a href="<?=BASE_URL?>india/delhi-tours/best-time-to-visit-delhi.html"><i class="fa fa-angle-right"></i>Best Time to Visit Delhi</a></li>
                <li><a href="#"><i class="fa fa-angle-right"></i>How to Reach Delhi</a></li>
                <li><a href="#"><i class="fa fa-angle-right"></i>Top Places to Visit in Delhi </a></li>
                <li><a href="#"><i class="fa fa-angle-right"></i>Top Things to do in Delhi</a></li>
              

                <div class="hide-guide-sidebar">                
                
           

             
              </div>
            
              <li class="morepkg"><a href="<?=BASE_URL?>india/travel-guide/index.html" class="click-more-sidebar">View More [+] </a></li>
              </ul>
            </div>
              
          </div>
           <?php include ('../../side_form.php') ?>
