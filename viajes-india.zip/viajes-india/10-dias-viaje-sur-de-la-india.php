<!DOCTYPE>
<html lang="es">
<head>  
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

     
  <title>11 dias viaje sur de la india </title>
  <meta name="description" content="11 dias viaje sur de la india  "/>
  <meta name="Keywords" content=" 11 dias viaje sur de la india "/>

  <?php include("../head.php"); ?>
  <!-- Form Css-->


</head>

<body class="wsmenucontainer clearfix">
  <!--header-->
    <?php include ('../header.php') ?>
    <!--End header-->

    <!---START BRIDCROM-->
  <section class="full-breds"><div class="container"><div class="bredcums"><?= breadcrumbs() ?></div></div></section>
  <!---END BRIDCROM-->


<section class="tour-itinerary-page">

  <section class="itinerary-oveview">
      <div class="container">


        <div class="new-header">  
        <h1>11 dias viaje sur de la india</h1>
        <div class="new-activity">
          
          <span class="activity-ranking">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star-half" aria-hidden="true"></i>
            <!-- <i class="fa fa-star-o" aria-hidden="true"></i> -->
          </span>

           <span class="activity-fact">142 Comentarios</span> 
        <!--    <span style="
    padding-left: 10px;
"><strong><i class="fa fa-clock-o"></i> </strong> 9 Nights / 10 Days</span> -->
          
          
          <!-- <span class="people-interested pull-right">
            <img src="https://www.tusktravel.com.mx/images/Interested-Icon.png" alt=""> 
            520 people interested today
          </span>  -->
        </div>  
        <div class="sightseeing-duration-destination">
          <ul class="ultourdestdur">
           <!-- <li class="tdour">
              <strong><i class="fa fa-clock-o"></i> </strong><span> 12 Noches / 13 Días</span>
            </li> -->
            <li class="tdestination"><strong> <i class="fa fa-globe"></i></strong>
              <span>Chennai – Kanchipuram - Mahabalipuram – Pondicherry - Tanjore - Trichy - Madurai - Munnar - Thekkady - Alleppey - Cochin </span>
            </li>
          </ul>     
        </div>
      </div>

        <div class="row">
          <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
            <div class="slider-holder">
              
              <div id="carousel-example-generic1" class="carousel slide" data-ride="carousel">
          <div class="carousel-inner">

            <div class="item active">
                <img src="<?=BASE_URL?>images/guest/south-india-tour-guest-nicole.jpg" />    
            </div>

         <div class="item">
         <img src="<?=BASE_URL?>images/southindia-tusktravel-02.jpg" />                
            </div>

            <div class="item">
                <img src="<?=BASE_URL?>images/goa-tusktravel-017.jpg" />                
            </div>
           
           <div class="item">
                <img src="<?=BASE_URL?>images/kerala-tusktravel-09.jpg" />                
            </div>

            <div class="item">
                <img src="<?=BASE_URL?>images/kerala-tusktravel-03.jpg" />                 
            </div>

           <div class="item">
                <img src="<?=BASE_URL?>images/southindia-tusktravel-04.jpg" />                
            </div>  

          <a class="left carousel-control" href="#carousel-example-generic1" role="button" data-slide="prev"><span class="glyphicon glyphicon-chevron-left"></span></a>
          <a class="right carousel-control" href="#carousel-example-generic1" role="button" data-slide="next"><span class="glyphicon glyphicon-chevron-right"></span></a>
       </div>
                            
</div>
               
            </div>
          </div>
          <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
            <div class="itinerary-overview_details">
              <div class="itinerary-description">
                Tour destacados
              </div>

              <ul class="highlight-this-tour">

<li>Comience desde Chennai y termine a Cochin.</li>
<li>Visita en Chennai – Iglesia, Museo, Templo Kapeeleshwara.</li>
<li>En Madurai, visita el templo Deenakshi Amann.</li>
<li>Visitas turísticas en vehículo privado con aire acondicionado</li>


				
				                
                <div class="hide-highlist">
                <li>Versatile y experto guía local de habla inglesa</li>
				<li>experto en viajes dedicado para todas sus necesidades de viaje</li>
				<li>100% Pagos Garantizados</li>
				
                </div>
                <div class="click-more-highlis">View More [+]</div>
              </ul>             
                
                <!-- BUTTON  START HERE-->
                <div class="support">
                  <?php include ('../button.php') ?>
                  <div class="custom-support">
                    <div class="custom-support-text">
                      Contacta a un experto de viajes en WhatsApp
                    </div>
                    <div class="custom-support-call">
                      <i class="fa fa-phone"></i> +91 920 500 2884
                    </div>
                  </div>                    
                </div>
                  <!-- BUTTON  end HERE-->
            </div>
          </div>
        </div>
     </div>    
  </section>


  <section class="itinerary-details">
    <div class="container">
     
      <div class="row">
        <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12"> 
   
          <div class="tour-overview"> 
            <!-- <h2 id="Tour-Overview"><i class="fa fa-file-text-o"></i> Descripción del viaje:</h2>  -->
            <p>Tusk Travel cubre un recorrido por el templo, un recorrido de aventura y la naturaleza, y un recorrido por el sur de la India en diez días. Un viaje por carretera en etapas simples a través de la India peninsular - el Malabar en el oeste, y la costa de Coromandel al este le lleva a los brillantes templos de Meenakshi, Mamallapuram, y Chidambaram, cada uno de ellos proporcionando una experiencia tentadora.</p>
<p>La Joya del Sur de la India le ofrece una oportunidad de por vida para presenciar un ritual de oración por la noche en el Templo de Meenakshi, mercados de verduras y flores, actuaciones de danza Kathakali celebradas en Kochi, y plantaciones de especias en Periyar.</p>
          </div>
         <div class="tour-collection">
           <h2><i class="fa fa-bus" aria-hidden="true"></i> Itinerario detallado</h2>

           <!-- start day colum-->        
            <div class="TourList">
              <div class="TourDates">
                <span class="TourDay_details" id="TourDay_details"><span class="TourDay">Día 1</span> Llegada a Chennai</span>
              </div>
              <div class="TourInfo">              
                <p>Bienvenidos a la India! Llegar a chennai cosmopolita en la bahía de Bengala, puerta de entrada al sur de la India; traslado al hotel. Tiempo para descansar, relajarse y aclimatarse a su nueva zona horaria o aventurarse a familiarizarse con algunos de los lugares extraordinarios de la ciudad y las animadas tiendas que venden vibrantes sarees de seda hechos a mano.</p>
<p><strong>Durante la Noche: </strong>Chennai</p>
              </div>
            </div>
            <!-- end day colum -->
            
            <!-- start day colum-->        
            <div class="TourList">
              <div class="TourDates">
                <span class="TourDay_details"><span class="TourDay">Día 2 :</span>Turismo en Chennai</span>
              </div>
              <div class="TourInfo">              
                <p>Después del desayuno en el hotel, salimos para visitas turísticas a Chennai. Visitemos ciudad <strong>es Fort St. George</strong> que marca el comienzo de Chennai como un importante centro para el comercio. Iglesia de <strong>Santa María</strong>, la primera iglesia inglesa en la India y el edificio británico más antiguo en sobrevivir.</p>
<p>Pasaremos algún tiempo en la zona del templo de Mylapore para visitar el templo Kapaleeswarar del siglo XVI y el mercado de frutas y flores. También visitamos el Museo gubernamental y la Galería de Arte, para ver la galería de arte y bronce y regreso a hotel.</p>
<p><strong>Durante la Noche: </strong>Chennai</p>
              </div>
            </div>
            <!-- end day colum -->     

            <!-- start day colum-->        
            <div class="TourList">
              <div class="TourDates">
                <span class="TourDay_details"><span class="TourDay">Día 3 :</span>Chennai - Kanchipuram - Mahabalipuram – Pondicherry (200 kms / 4.5 hrs)</span>
              </div>
              <div class="TourInfo">              
                <p>Por la mañana depues de Desayuno y chek out el hotel. Luego conduciremos a Pondicherry.enrouta visitaremos Kanchipuram y Mahabalipuram. Llegada en Pondicherry translado en el hotel y descansa.</p>
<p><strong>Durante la Noche: </strong>Pondicherry</p>
              </div>
            </div>
            <!-- end day colum -->

            <!-- start day colum-->        
            <div class="TourList">
              <div class="TourDates">
                <span class="TourDay_details"><span class="TourDay">Día 4 :</span>Pondicherry – Tanjore (170 kms / 3.5 hrs)</span>
              </div>
              <div class="TourInfo">              
                <p>Por las mañanas después del desayuno proceder para hacer turismo de Pondicherry, incluyendo el municipio de Auroville, Sri Aurobindo Ashram, la famosa playa del paseo marítimo y el templo Manakula Vinayagar Devasthanam , la estatua Mahatma Gandhi y el monumento a la guerra francesa.</p>
<p>Más tarde conduciremos a Tanjore. A la llegada traslado al hotel y el resto del día gratis</p>
<p><strong>Durante la Noche: </strong>Tanjore</p>
              </div>
            </div>
            <!-- end day colum -->
            <!-- start day colum-->        
            <div class="TourList">
              <div class="TourDates">
                <span class="TourDay_details"><span class="TourDay">Día 5 :</span>Tanjore –Trichy - Madurai (190 kms /4 hrs)</span>
              </div>
              <div class="TourInfo">              
                <p>Comience el día con una visita al gran <strong>Templo de Lord Brihadeeswarar</strong>, declarado Patrimonio de la Humanidad por la UNESCO, donde miles de personas adoran diariamente y <strong>Maratha Palace</strong>.</p>
<p>Luego conduciremos <strong>Madura</strong>i Enrouta visitemos <strong>Trichy</strong> y visitemos <strong>Amma Mandapam</strong>,<strong> Ranganathaswamy Temple</strong>. Luego conduciremos a Madurai. su llegada en Madurai translado en el hotel.</p>
<p><strong>Durante la Noche: </strong>Madurai</p>
              </div>
            </div>
            <!-- end day colum -->

            <!-- start day colum-->        
            <div class="TourList">
              <div class="TourDates">
                <span class="TourDay_details"><span class="TourDay">Día 6 :</span>Madurai – Munnar (170 kms /5 hrs)</span>
              </div>
              <div class="TourInfo">              
                <p>Por la mañana después del desayuno de nuevo visite el Templo de Meenakshi, un enorme complejo del templo dedicado al Señor Shiva y su esposa Parvati o Meenakshi y El templo de Meenakshi es el Salón de un "Mil Pilares", construido en el siglo XVI; cada pilar esculpido en la arquitectura dravidina. Luego visite el Palacio <strong>Thirumalai Nayak -</strong> un elegante edificio de estilo indo-saracenic, famoso por el trabajo de estuco en sus cúpulas y arcos.</p>
<p>Luego cocnduciremos a Munnar.su llegada en Munnar translado en el hotel.</p>
<p><strong>Durante la Noche: </strong>Munnar</p>
              </div>
            </div>
            <!-- end day colum -->

            <!-- start day colum-->        
            <div class="TourList">
              <div class="TourDates">
                <span class="TourDay_details"><span class="TourDay">Día 7 :</span>Turismo de Munnar</span>
              </div>
              <div class="TourInfo">              
                <p>Por la mañana después del desayuno recorremos la ciudad de la estación de la colina. Visitaremos  <strong>Pico Anamudi, </strong>el pico más alto de los Ghats occidentales, en el sur de la India. Una promesa de salud con su sol relajante, su clima salubre y el aroma vigorizante del aire de los jardines de té. También visitamos un <strong>Museo del Té</strong>. Regreso posterior al hotel</p>
<p><strong>Durante la Noche: </strong>Munnar</p>
              </div>
            </div>
            <!-- end day colum -->

            <!-- start day colum-->        
            <div class="TourList">
              <div class="TourDates">
                <span class="TourDay_details"><span class="TourDay">Día 8 :</span>Munnar – Thekkady (100 Kms/1 Hrs) </span>
              </div>
              <div class="TourInfo">              
                <p>Hoy en día, conducir al Parque Nacional Periyar encaramado en lo alto de las colinas de cardamomo, el santuario de vida silvestre más conocido en el sur de la India, hogar de elefantes, antílopes, ciervos y muchas especies de aves.</p>
<p>Después de un tiempo para relajarse y instalarse en el hotel, pasee tranquilamente por una de las plantaciones de especias de la zona. Escucharás sobre las diferentes maneras de usar estas especias tanto en los medicamentos como en la preparación de alimentos. Por la noche, únase al Kalaripayattu Martial Art Show.</p>
<p>Kalaripayattu, uno de los estilos de lucha más antiguos del mundo, se cree que fue adaptado de varias formas de arte marcial como karate, kung-fu y judo. Más tarde regreso al hotel.</p>
<p><strong>Durante la Noche: </strong>Thekkady</p>
              </div>
            </div>
            <!-- end day colum -->

            <!-- start day colum-->        
            <div class="TourList">
              <div class="TourDates">
                <span class="TourDay_details"><span class="TourDay">Día 9 :</span>Thekkady – Alleppey (140 Kms/3.5 Hrs) </span>
              </div>
              <div class="TourInfo">              
                <p>Por la mañana vamos a ir a dar un paseo en barco en el lago; esta es también la forma habitual de recorrer el Santuario de Vida Silvestre Periyar. Los cruceros en barco son la mejor opción para echar un vistazo a la vida silvestre del Santuario de Periyar. Usted puede ver una familia de elefantes, jabalíes salvajes y ciervos Sambar por el borde del agua. Más tarde retunn al hotel para el desayuno.</p>
<p>Después del desayuno en auto a Alleppey. Alleppey revela está tranquila región de remanso de Kerala. Abordando una casa flotante, se navega a lo largo de esta red muy intrincada de canales, lagos, lagunas y ríos llamados la "Venecia del Este".</p>
<p><strong>Durante la Noche: </strong>Alleppey (Houseboat)</p>
              </div>
            </div>
            <!-- end day colum -->

			<!-- start day colum-->        
            <div class="TourList">
              <div class="TourDates">
                <span class="TourDay_details"><span class="TourDay">Día 10 :</span>Alleppey - Cochin (55 Kms/1.5 Hrs) </span>
              </div>
              <div class="TourInfo">              
                <p>Mañana después de desembarcar de la casa flotante y conducir a Cochin. Kochi (nombre colonial Cochin) es una vibrante ciudad situada en la costa suroeste de la península india en el impresionante y próspero estado de Kerala, aclamada como "El propio país de Dios".</p>
<p>A la llegada proceder para hacer turismo, incluyendo visitar la Iglesia de <strong>San Francisco</strong> considerada la primera Iglesia Europea en la India, construida en 1562 por St. Continúe hacia <strong>Mattanchery Dutch</strong> <strong>Palace</strong>, <strong>Jewish Synagogue</strong>, <strong>Chinese Fishing Nets" y regreso a hotel.</strong></p>
<p><strong>Durante la Noche: </strong>Cochin</p>
              </div>
            </div>
            <!-- end day colum -->
            
            <!-- start day colum-->        
            <div class="TourList">
              <div class="TourDates">
                <span class="TourDay_details"><span class="TourDay">Día 11 :</span>Cochin - Salida </span>
              </div>
              <div class="TourInfo">              
                <p>Desayuno en el hotel. Más tarde en el tiempo traslado al aeropuerto para abordar en su vuelo de casa con feliz memonries de su recorrido con nosotros</p>
              </div>
            </div>
            <!-- end day colum -->

           
           


          </div>
          
 
          <!-- BUTTON  START HERE-->
            <?php include ('../button.php') ?>
            <!-- BUTTON  START HERE-->
      
            </div>
        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
          <?php include ('tours-sidebar.php') ?>
                    
        </div>
      </div>
    </div>
  </section>
  
  <?php include ('recomen-india.php') ?>
  <?php include ('recomen-combin.php') ?>
</section>
    

  <!--footer-->
 <?php include ('../footer.php') ?> 
 <?php include ('../model.php') ?>
 <?php include ('../script.php') ?>

</body>
</html>

