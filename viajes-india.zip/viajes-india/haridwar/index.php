<!DOCTYPE>
<html lang="es">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <title>Viajes a Haridwar, Itinerario de Haridwar, Paquetes de Viajes Haridwar a 2023-2024</title>
      <meta name="Description" content="Solicite gratis su presupuesto de viaje a Haridwar 100% personalizado con una agencia local. Viaje auténtico a Haridwar paquetes. Consulte el itinerario de la viaje por Haridwar de cinco a diez días o de 5 a 20 días."/>
      <meta name="Keywords" content="viaje Haridwar, paquetes Haridwar, Haridwar tour, Haridwar itinerario, Haridwar Viajes"/>
      <?php include("../../head.php"); ?>
      <link rel="stylesheet" href="<?=BASE_URL?>css/slippry-2.css">
      <link rel="stylesheet" href="<?=BASE_URL?>css/owl.carousel.css"/>
   </head>
   <body class="wsmenucontainer clearfix">
      <!--header-->
      <?php include ('../../header.php') ?>
      <!--End header-->
      <!--START BANNER HTML CODE-->
      <section class="slier_holer">
         <section id="news-demo" style="overflow:hidden">
            <article><img src="<?=BASE_URL?>images/banner/haridwar-tt.jpg" width="" alt="haridwar Viajes" /></article>
         </section>
         <div class="home-banner-caption">
            <div class="banner-text-holder">
               <div class="title">Viajes a Haridwar</div>
               <div class="tagline">Viajes Haridwar es una agencia de viajes especializada en viajes a India</div>
            </div>
         </div>
      </section>
      <section id="about_info_this_page" class="topover_view padding-35">
         <div class="container">
            <div class="row">
               <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                  <article>
                     <h1 class="banner-caption-heading">Paquetes de Viajes a Haridwar 2023-2024</h1>
                     <p class="banner-caption-tag-line">
   <p>Como sugiere el nombre en su significado literal: "Puerta de entrada al Señor Vishnu", se convierte en una de las ciudades sagradas para los hindúes y en un placer cultural en medio de la naturaleza para otros. Haridwar es considerado uno de los siete lugares sagrados para los hindúes. Es aquí donde el río Ganges comienza a adentrarse en las llanuras después de descender desde el glaciar Gangothri.</p>

                     <div class="more-read">
                        
<h2>Haridwar - Guía de la ciudad</h2>
<p>Haridwar también es un lugar especial ya que según la mitología hindú se cree que Amrit, el elixir de la inmortalidad, cayó aquí junto con otros tres lugares mientras se transportaba a Garuda, el ave celestial. Este episodio se celebra una vez cada 12 años. Se llama Haridwar Kumbh Mela, que cuenta con millones de devotos, peregrinos y turistas que vienen a presenciar la exótica reunión masiva.</p>
<p>El lugar donde esto ocurre es el mismo donde se cree que cayó el elixir, llamado 'Hari Ki Pauri' o 'Paso del Señor Vishnu'. Es un área bien delimitada que también denota dónde había pisado Lord Vishnu.</p>
<p>No debe perderse el Arti (culto ritual con inciensos y lámparas) que tiene lugar todas las mañanas y tardes en las orillas de este lugar. Es la mejor manera de aprender las tradiciones religiosas del hinduismo. A medida que avanza el Arti, el río y el cielo crean una hermosa escena en sí misma.</p>
<p>También se puede visitar el "Santuario de Vida Silvestre de Chilla" y el "Parque Nacional Rajaji", donde los Safaris en Jeep a través del bosque le permiten ver ciervos ladrando, langures grises, ciervos manchados, ciervos sambhar, halcones, cálaos, halcones y más. Es una pequeña escapada del área concurrida que atrae a los entusiastas de la vida silvestre y los observadores de aves.</p>
<p>Además, la visita al Templo Doodhadhari Barfani puede ser diferente de las que encontraría comúnmente en Haridwar. Construido en mármol, puede interesar a las personas con una inclinación hacia la arquitectura. Por otro lado, Bara Bazaar es para personas interesadas en los mercados locales y el estilo de vida local de Haridwar. En general, Haridwar es una pequeña ciudad con su propio encanto y sencillez que se puede experimentar en su verdadera esencia.</p>
<p><strong>Condición climática</strong></p>
<p>Haridwar sigue siendo agradable durante la mayor parte de los meses, debido a su posición geográfica. Sin embargo, también es propenso a lluvias repentinas, aunque de julio a septiembre hay fuertes aguaceros. Los inviernos son fríos con temperaturas entre 6° C y 16° C que se extienden de octubre a marzo. El verano sigue siendo moderado con junio como el mes más caluroso y la temperatura oscila entre los 20 °C y los 40 °C.</p>
<p><strong>Principales Atracciones</strong></p>
<p>Haridwar Kumbh Mela, Hari Ki Pauri, Parque Nacional Rajaji, Santuario de Vida Silvestre Chilla, Templo Doodhadhari Barfani, Bazar Bara</p>
<p><strong>Mejor tiempo para visitar</strong></p>
<p>octubre a abril</p>
                     </div>
                     <a href="#" class="click_me" style="margin-left:0">Lee mas +</a>
                  </article>
               </div>
            </div>
         </div>
      </section>
     
<section class="package-1-format">  
<div class="container">
   <div class="row less-pading-row">

<div class="col-md-4 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>paquetes/15-dias-viaje-india-y-nepal.html"> <img src="<?=BASE_URL?>img/guest/varanasi-ganges-spiritual-experience.jpg" alt="Varanasi Ganges Spiritual Experience"></a> 
                            <div class="thumbnail-ribbon">
                              <span>Más popular</span>
                            </div>
                        </div>
                        <div class="destination-content-1">
                          <h3><a href="<?=BASE_URL?>paquetes/15-dias-viaje-india-y-nepal.html">15 Días – Viaje India y Nepal</a></h3>
                          <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Delhi - Udaipur - Ranakpur - Jodhpur - Jaipur - Agra - Khajuraho -Varanasi - Kathmandu - Pokhara
                            </div>
                              <p class="package-days1"><i class="flaticon-time"></i> 15 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>paquetes/15-dias-viaje-india-y-nepal.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>

<div class="col-md-4 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>paquetes/viajes-india-y-maldivas.html">
                            <img src="<?=BASE_URL?>img/maldives-scuba-diving-05.jpg" width="100%" alt="">
                           </a>
                           <div class="thumbnail-ribbon">
                              <span>Más popular</span>
                            </div>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>paquetes/viajes-india-y-maldivas.html">14 Días – Viajes India y Maldivas</a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Delhi – Agra – Jaipur – Varanasi – Delhi - Male - Salida
                            </div>
                            <p class="package-days1"><i class="flaticon-time"></i> 14 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star-o"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>paquetes/viajes-india-y-maldivas.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>



<div class="col-md-4 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>paquetes/india-y-nepal-viaje-en-20-dias.html"><img src="<?=BASE_URL?>img/nepal-tusktravel-00.jpg" width="100%" alt="tour packages">
                            <div class="thumbnail-ribbon">
                                 <span>Más popular</span>
                              </div>
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>paquetes/india-y-nepal-viaje-en-20-dias.html">20 Días – Viaje Mejor de India y Nepal </a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Delhi – Udaipur – Ranakpur - Jodhpur – Jaipur – Fatehpur Sikri - Agra - Delhi - Varanasi - Delhi - Katmandú - Nagarkot - Delhi
                            </div>

                            <p class="package-days1"><i class="flaticon-time"></i> 10 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star-o"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>paquetes/india-y-nepal-viaje-en-20-dias.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>viajes-india/triangulo-de-oro-india-en-7-dias.html"><img src="<?=BASE_URL?>img/guest/varanasi-guest-arrival.jpg" width="100%" alt="tour packages"> 
                            <div class="thumbnail-ribbon">
                              <span>Más popular</span>
                            </div>
                            

                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>viajes-india/triangulo-de-oro-india-en-7-dias.html">7 Días – Triángulo de oro India (Delhi Agra jaipur)</a></h3>

                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Nueva Delhi - Agra - Fatehpur Sikri - Jaipur - Delhi
                            </div>

                            <p class="package-days1"><i class="flaticon-time"></i> 7 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>viajes-india/triangulo-de-oro-india-en-7-dias.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>
               
                

                <div class="col-md-4 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>viajes-india/viaje-rajasthan-en-10-dias.html"><img src="<?=BASE_URL?>img/rajasthan-tusktravel-016.jpg" width="100%" alt="viaje rajasthan en 10 dias">
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>viajes-india/viaje-rajasthan-en-10-dias.html">10 Días – Viajes a Rajasthán y Taj Mahal (Cultura de la India)</a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                             Delhi - Agra - Jaipur - Jodhpur - Udaipur - Delhi
                            </div>
                            <p class="package-days1"><i class="flaticon-time"></i> 10 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>viajes-india/viaje-rajasthan-en-10-dias.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>
                              
                

                <div class="col-md-4 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>viajes-india/triangulo-dorado-y-haridwar-rishikesh-viaje.html"><img src="<?=BASE_URL?>img/rishikesh-tusktravel-01.jpg" width="100%" alt="">
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>viajes-india/triangulo-dorado-y-haridwar-rishikesh-viaje.html">9 Días – Triángulo de Oro con Yoga y Meditación</a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Delhi - Jaipur - Agra - Haridwar - Rishikesh - Delhi
                            </div>
                            <p class="package-days1"><i class="flaticon-time"></i> 9 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star-o"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>viajes-india/triangulo-dorado-y-haridwar-rishikesh-viaje.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>

   <div class="clearfix"> </div>

 <div class="col-md-3 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>paquetes/viaje-a-india-nepal-y-butan.html">
                            <img src="<?=BASE_URL?>img/nepal-tusktravel-013.jpg" width="100%" alt="">
                            <div class="thumbnail-ribbon">
                                 <span>Más popular</span>
                              </div>
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>paquetes/viaje-a-india-nepal-y-butan.html">14 Días – Viaje India, Nepal y Bután</a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Delhi – Jaipur – Agra – Katmandú -  Paro – Thimpu - Delhi - Salida
                            </div>
                            <p class="package-days1"><i class="flaticon-time"></i> 14 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star-o"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>paquetes/viaje-a-india-nepal-y-butan.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>

 


                 <div class="col-md-3 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>paquetes/viaje-india-y-tailandia-paquetes.html">
                            <img src="<?=BASE_URL?>img/tailandia-tusktravel-03.jpg" width="100%" alt="">
                            <div class="thumbnail-ribbon">
                                 <span>Más popular</span>
                              </div>
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>paquetes/viaje-india-y-tailandia-paquetes.html">14 Días – Viaje Paquetes India y Tailandia</a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Delhi - Jaipur - Agra - Khajuraho - Varanasi - Chaing Mai - Phuket - Bangkok
                            </div>
                            <p class="package-days1"><i class="flaticon-time"></i> 14 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star-o"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>paquetes/viaje-india-y-tailandia-paquetes.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>

<div class="col-md-3 col-sm-4 col-xs-12 less-pading-col">
                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>viajes-india/viajes-rajasthan-y-varanasi.html"><img src="<?=BASE_URL?>img/guest/jaipur-elephant-ride-guest.jpg" width="100%" alt="">
                           </a>
                        </div>
                        <div class="destination-content-1">
                            <h3><a href="<?=BASE_URL?>viajes-india/viajes-rajasthan-y-varanasi.html">14 Días – India Rajasthan y Benarés </a></h3>
                            <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Delhi - Udaipur – Ranakpur – Jodhpur - Jaipur - Agra - Delhi - Varanasi - Delhi
                            </div>
                            <p class="package-days1"><i class="flaticon-time"></i> 14 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star-o"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>viajes-india/viajes-rajasthan-y-varanasi.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>
       

<div class="col-md-3 col-sm-4 col-xs-12 less-pading-col">

                    <div class="destination-item-1 box-item">
                        <div class="destination-image-1">
                           <a href="<?=BASE_URL?>paquetes/viaje-paquetes-india-y-dubai.html"> <img src="<?=BASE_URL?>img/dubai-tusktravel-00.jpg" alt="Varanasi Ganges Spiritual Experience"></a> 
                            <div class="thumbnail-ribbon">
                              <span>Más popular</span>
                            </div>
                        </div>
                        <div class="destination-content-1">
                          <h3><a href="<?=BASE_URL?>paquetes/viaje-paquetes-india-y-dubai.html">14 Días – Viaje India y Dubái </a></h3>
                          <div class="tour-route-details">
                              <i class="fa fa-map-marker" aria-hidden="true"></i> 
                              Delhi - Jaipur - Agra - Khajuraho - Varanasi - Delhi - Dubai - Salida
                            </div>
                              <p class="package-days1"><i class="flaticon-time"></i> 15 Días</p>
                            <div class="deal-rating">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                            </div>
                          <div class="tour-book">
                            <span class="book-now"><a href="<?=BASE_URL?>paquetes/viaje-paquetes-india-y-dubai.html">Ver Detalles</a></span>
                          </div>
                        </div>
                    </div>
                </div>

              
                
 
</div>
</section>

      
      <?php include ('../../footer.php') ?> 
      <!--End footer-->
      <?php include ('../../model.php') ?>
      <?php include ('../../script.php') ?>
   </body>
</html>