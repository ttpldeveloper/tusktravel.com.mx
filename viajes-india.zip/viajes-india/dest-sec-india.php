<section class="destination-area">
      <h2 class="text-center">Destinos más populares de la India</h2>
      <div class="container">

        <div class="col-md-3 col-sm-4 col-xs-6 widget">
          <div class="tusk-destination-col">
            <a href="<?=BASE_URL?>viajes-india/rajastan/" class="box">
            <img src="../../img/rajasthan-375-tt.jpg" class="img-responsive">        
            <b>Rajastán</b>
            </a>
          </div>
        </div>
          <div class="col-md-3 col-sm-4 col-xs-6 widget">
          <div class="tusk-destination-col">
            <a href="<?=BASE_URL?>viajes-india/triangulo-de-oro-india/" class="box">
            <img src="../../img/golden-triangle-375-tt.jpg" class="img-responsive">        
            <b>Triángulo de oro</b>
            </a>
          </div>
        </div>

      
        <div class="col-md-3 col-sm-4 col-xs-6 widget">
          <div class="tusk-destination-col">
            <a href="<?=BASE_URL?>viajes-india/norte-de-india/" class="box">
            <img src="../../img/north-india-375-tt.jpg" class="img-responsive">        
            <b>Norte India</b>
            </a>
          </div>
        </div>


        <div class="col-md-3 col-sm-4 col-xs-6 widget">
          <div class="tusk-destination-col">
            <a href="<?=BASE_URL?>viajes-india/sur-de-india/" class="box">
            <img src="../../img/south-375-tt.jpg" class="img-responsive">        
            <b>Sur India</b>
            </a>
          </div>
        </div>




        
        <div class="col-md-3 col-sm-4 col-xs-6 widget">
          <div class="tusk-destination-col">
            <a href="<?=BASE_URL?>viajes-india/agra/" class="box">
            <img src="../../img/agra-375-tt.jpg" class="img-responsive">        
            <b>Agra</b>
            </a>
          </div>
        </div>

       <div class="col-md-3 col-sm-4 col-xs-6 widget">
          <div class="tusk-destination-col">
            <a href="<?=BASE_URL?>viajes-india/delhi/" class="box">
            <img src="../../img/delhi-375-tt.jpg" class="img-responsive">        
            <b>Delhi</b>
            </a>
          </div>
        </div>
        <div class="col-md-3 col-sm-4 col-xs-6 widget">
          <div class="tusk-destination-col">
            <a href="<?=BASE_URL?>viajes-india/kerala/" class="box">
            <img src="../../img/kerala-375-tt.jpg" class="img-responsive">        
            <b>Kerala</b>
            </a>
          </div>
        </div>
         <div class="col-md-3 col-sm-4 col-xs-6 widget">
          <div class="tusk-destination-col">
            <a href="<?=BASE_URL?>viajes-india/benares/" class="box">
            <img src="../../img/varanasi-375-tt.jpg" class="img-responsive">        
            <b>Benarés</b>
            </a>
          </div>
        </div>
        <div class="clearfix"></div>

</div>
</div>
</section>