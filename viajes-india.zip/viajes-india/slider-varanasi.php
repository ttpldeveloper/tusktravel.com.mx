<div id="carousel-example-generic1" class="carousel slide" data-ride="carousel">
          <div class="carousel-inner">
            <div class="item active">
                <img src="<?=BASE_URL?>images/guest/delhi-jaipur-amer-fort-palace.jpg" />    
            </div>

                 <div class="item">
                <img src="<?=BASE_URL?>images/guest/jaipur-city-palace-elephant.jpg" />
            </div>

           <div class="item">
                <img src="<?=BASE_URL?>images/guest/agra-city-sightseeing.jpg" />
            </div>
           
           <div class="item">
                <img src="<?=BASE_URL?>images/guest/jodhpur-city-tour-tusktravel.jpg" />
            </div>


            <div class="item">
                <img src="<?=BASE_URL?>images/agra-tusktravel-01.jpg" />
            </div>

             <div class="item">
                <img src="<?=BASE_URL?>images/jaipur-tusktravel-01.jpg" />
            </div>

            <div class="item">
               <img src="<?=BASE_URL?>images/delhi-tusktravel-01.jpg" />
            </div>
          <a class="left carousel-control" href="#carousel-example-generic1" role="button" data-slide="prev"><span class="glyphicon glyphicon-chevron-left"></span></a>
          <a class="right carousel-control" href="#carousel-example-generic1" role="button" data-slide="next"><span class="glyphicon glyphicon-chevron-right"></span></a>
       </div>
</div>



    <!-- #region Jssor Slider Begin -->
    <!-- Generator: Jssor Slider Maker -->
    <!-- Source: https://www.jssor.com -->
    <!-- <script src="js/jquery-1.11.3.min.js" type="text/javascript"></script> -->


    

    <div id="jssor_1" style="position: relative; top: 0px; left: 0px; width: 750px; height: 442px; overflow: hidden; ">
        <!-- Loading Screen -->
        <div data-u="loading" class="jssorl-009-spin">
            <img style="margin-top:-19px;position:relative;top:50%;width:38px;height:38px;" src="img/spin.svg" />
        </div>
        <div data-u="slides" style="cursor:default;position:relative;top:0px;left:0px;width:750px; height:442px;">
            <div>
                <img data-u="image" src="<?=BASE_URL?>images/varanasi-tusktravel-00.jpg" />
                <img data-u="thumb" src="<?=BASE_URL?>images/varanasi-tusktravel-00.jpg" />
            </div>
           
            <div>
                <img data-u="image" src="<?=BASE_URL?>images/varanasi-tusktravel-01.jpg" />
                <img data-u="thumb" src="<?=BASE_URL?>images/varanasi-tusktravel-01.jpg" />
            </div>
            <div>
                <img data-u="image" src="<?=BASE_URL?>images/varanasi-tusktravel-02.jpg" />
                <img data-u="thumb" src="<?=BASE_URL?>images/varanasi-tusktravel-02.jpg" />
            </div>
            <div>
                <img data-u="image" src="<?=BASE_URL?>images/varanasi-tusktravel-03.jpg" />
                <img data-u="thumb" src="<?=BASE_URL?>images/varanasi-tusktravel-03.jpg" />
            </div>
            <div>
                <img data-u="image" src="<?=BASE_URL?>images/varanasi-tusktravel-04.jpg" />
                <img data-u="thumb" src="<?=BASE_URL?>images/varanasi-tusktravel-04.jpg" />
            </div>
            <div>
                <img data-u="image" src="<?=BASE_URL?>images/varanasi-tusktravel-05.jpg" />
                <img data-u="thumb" src="<?=BASE_URL?>images/varanasi-tusktravel-05.jpg" />
            </div>
         
        </div>
        <!-- Thumbnail Navigator -->
        <div data-u="thumbnavigator" class="jssort101" style="position:absolute;left:0px;bottom:0px;width:980px;height:100px;background-color:#000;" data-autocenter="1" data-scale-bottom="0.75">
            <div data-u="slides">
                <div data-u="prototype" class="p" style="width:190px;height:90px;">
                    <div data-u="thumbnailtemplate" class="t"></div>
                    <svg viewbox="0 0 16000 16000" class="cv">
                        <line class="a" x1="6190.5" y1="8000" x2="9809.5" y2="8000"></line>
                        <line class="a" x1="8000" y1="9809.5" x2="8000" y2="6190.5"></line>
                    </svg>
                </div>
            </div>
        </div>
        <!-- Arrow Navigator -->
        <div data-u="arrowleft" class="jssora106" style="width:55px;height:55px;top:162px;left:30px;" data-scale="0.75">
            <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                <polyline class="a" points="7930.4,5495.7 5426.1,8000 7930.4,10504.3 "></polyline>
                <line class="a" x1="10573.9" y1="8000" x2="5426.1" y2="8000"></line>
            </svg>
        </div>
        <div data-u="arrowright" class="jssora106" style="width:55px;height:55px;top:162px;right:30px;" data-scale="0.75">
            <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
            
                <polyline class="a" points="8069.6,5495.7 10573.9,8000 8069.6,10504.3"></polyline>
                <line class="a" x1="5426.1" y1="8000" x2="10573.9" y2="8000"></line>
            </svg>
        </div>
    </div>
    <!-- #endregion Jssor Slider End -->
   
